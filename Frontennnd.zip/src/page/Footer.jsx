import { Link } from "react-router-dom";
const Footer = () => {
  return (
    <div class="container-fluid p-1 bg-success text-center text-white">
    <p>@copyright hospital.com</p>
  </div>
  );
};

export default Footer;
