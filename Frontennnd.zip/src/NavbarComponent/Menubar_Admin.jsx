import React, { Component } from 'react'
import { Link } from 'react-router-dom'
// import  './style.css'
class MenuBar_Admin extends Component {
    render() {
        return (
            <div>
              <div class="search-container">
    <form action="/contact">
      <input type="text" placeholder="Search.." name="search">
        </input>
      <button type="submit">Submit</button>
    </form>
  </div>
    
  
             <img src={require('./img4.jpg')}height={528} width={1232} ></img>
   
             <h4><span>Doctors</span></h4>
<div class="row g-2">

        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/LohyFIN.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Ankita Jais</h5>
                <small>Neurosurgeon</small>
                <small>Experience-10 Yrs</small>

                <div class="ratings mt-2">

                    <i class="fa fa-star">**</i>
                    <i class="fa fa-star">*</i>
                    <i class="fa fa-star">*</i>
                    <i class="fa fa-star">*</i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>




        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/o5uMfKo.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Tanya Jaiswal</h5>
                <small>Cardiologist</small>
                <small>Experience-8 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">***</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>




        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/tmdHXOY.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Chayan Jain</h5>
                <small>Surgeon</small>
                <small>Experience-20 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">****</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>




        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/C4egmYM.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Paul Reddy</h5>
                <small>Dentist</small>
                <small>Experience-25 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">*****</i>
                    <i class="fa fa-star"></i>
                   
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>



        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/HFpxxJz.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Anushka jain</h5>
                <small>Eye Specialist</small>
                <small>Experience-6 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">**</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>


        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/ZSkeqnd.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Tina Gupta</h5>
                <small>Urology</small>
                <small>Experience-12 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">****</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>



        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/MZm1LNz.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Anjani Jorawanshi</h5>
                <small>Neurosurgeon</small>
                <small>Experience-18 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">****</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>



        <div class="col-md-3">

            <div class="card p-2 py-3 text-center">

                <div class="img mb-2">

                    <img src="https://i.imgur.com/HFpxxJz.jpg" width="70" class="rounded-circle"></img>
                    
                </div>

                <h5 class="mb-0">Patey Cruiser</h5>
                <small>Neurosurgeon</small>
                <small>Experience-22 Yrs</small>
                <div class="ratings mt-2">

                    <i class="fa fa-star">*****</i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    
                </div>

                <div class="mt-4 apointment">

                <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/patient/appointment/take">Book Appointment</Link></button>
                    
                </div>

            </div>
            
        </div>



        <Link to='/'>
            <button className="login-btn">Go Back</button>
        </Link>     

</div>



            </div>
        )
    }
}
export default MenuBar_Admin