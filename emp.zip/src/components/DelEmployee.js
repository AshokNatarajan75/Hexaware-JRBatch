import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function DelEmployee() {
  const [employee, setEmployee] = useState({ id: '' });
  const navigate = useNavigate();

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setEmployee({ ...employee, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .delete(`http://localhost:8000/employees/${employee.id}`)
      .then((response) => {
        console.log('Employee Deleted:', response.data);
        navigate('/employees');
      })
      .catch((error) => {
        console.error('Error Deleting employee:', error);
      });
  };

  return (
    <div>
      <h2>Delete Employee</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>ID</label>
          <input
            type="text"
            name="id" 
            value={employee.id}
            onChange={handleInputChange}
            className="form-control"
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Delete Employee
        </button>
      </form>
    </div>
  );
}

export default DelEmployee;




/*


import React, { useState } from 'react';
import axios from 'axios';

function DelEmployee() {
  const [employee, setEmployee] = useState({ id:'' });

  const handleInputChange = (event) => {
    const { id ,value} = event.target;
    setEmployee({...employee, [id]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault()
    axios.delete('http://localhost:8000/employees/{id}', employee)
      .then((response) => {
        console.log('Employee Deleted:', response.data);
      })
      .catch((error) => {
        console.error('Error Deleting employee:', error);
      });
  };

  return (
    <div>
      <h2>Delete Employee</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>ID</label>
          <input
            type="text"
            name="id"
            value={employee.id}
            onChange={handleInputChange}
            className="form-control"
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Delete Employee
        </button>
      </form>
    </div>
  );
}

export default DelEmployee;   */
