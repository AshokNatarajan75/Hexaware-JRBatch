import {  useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import validator from "validator";
function Register_Reseptionist() {
  
    const [employeename, setEmployeename] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState('');

    const navigate = useNavigate();
    async function save(event) {
        event.preventDefault();
        if(errors==="Is Strong Password"){
          try {
          await axios.post("http://localhost:8080/api/v1/employee/save", {
          employeename: employeename,
          email: email,
          password: password,
          });
          alert("Employee Registation Successfully");
          navigate('/login_receptionist');

          } catch (err) {
            alert(err);
          }
        } else {
          alert(errors);
        }
      }

      const validate = (value) => {
        if(validator.isStrongPassword(value, {
          minLength: 8, minLowercase: 1, minNumbers: 1,
          minSymbols: 1, minUppercase: 1
        })){
        setErrors('Is Strong Password')
        setPassword(value)
        }
      else {
        setErrors('Is not a strong Password')
      }
    }

    return (
        <div>
        <div className="auth-form-container">
            <h1>Register Receptionist</h1>
        <form className="register-form" onSubmit={save}>
          <label>Receptionist name</label>
          <input 
          type="text" 
          id="employeename" 
          placeholder="Enter Name"
          value={employeename}
          onChange={(event) => {
            setEmployeename(event.target.value);
          }}
          required/>
          <label>Email</label>
          <input 
          type="email"  
          id="email" 
          placeholder="Enter Email"
          value={email}
          onChange={(event) => {
            setEmail(event.target.value);
          }}
          required/>
          <label>Password</label>
            <input 
            type="password"  
            id="password" 
            placeholder="Enter password"
            //value={password}
            onChange={(e) => validate(e.target.value)}
            required/>
                            {errors === '' ? null :
                    <span style={{
                        fontWeight: 'bold',
                        color: 'red',
                    }}>{errors}</span>}
            <button type="submit" class="login-btn" >Sign Up</button>
            </form>
        <Link to='/login_receptionist'>
            <button className="link-btn">Already have an account.<br/> Login</button>
        </Link>
        <Link to='/login_receptionist'>
            <button className="login-btn">Go Back</button>
        </Link>
    </div>

    </div>
    );
  }
  
  export default Register_Reseptionist;