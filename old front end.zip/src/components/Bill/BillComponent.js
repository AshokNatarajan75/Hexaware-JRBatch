import axios from 'axios';
import React from 'react'
import { Button, Row } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import MenuBar from '../Home/MenuBar';
class BillComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            bills: [],
            currentPage: 1,
            recordPerPage: 7,
            search: '',
            patientName: '',
            results: [],
        }
    }
    componentDidMount() {
        this.getBillsByPagination(this.state.currentPage);
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.state.patientName !== prevState.patientName) {
            if (this.state.patientName) {
                axios.get(`http://localhost:8080/api/v1/search_bill?patientName=${this.state.patientName}`)
                    .then(response => {
                        console.log(response.data); 
                        this.setState({ results: response.data });})
                    .catch(error => console.error(error));
            } else {
                this.setState({ results: [] });
            }
        }
    }

    handleInputChange = e => {
        this.setState({ patientName: e.target.value });
    };

    getBillsByPagination(currentPage) {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/bills?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    bills: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    }
    //Writing All the pagination functions
    //Show Next page
    showNextPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getBillsByPagination(this.state.currentPage + 1);
            } else {
                this.searchBillSchedule(this.state.currentPage + 1)
            }
        }
    };
    //Show Last Page
    showLastPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getBillsByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
            else {
                this.searchBillSchedule(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
        }
    };
    //Show First page
    showFirstPage = () => {
        let firstPage = 1;
        if (this.state.currentPage > firstPage) {
            if (!this.state.search) {
                this.getBillsByPagination(firstPage);
            } else {
                this.searchBillSchedule(firstPage)
            }
        }
    };
    //Show previous page
    showPrevPage = () => {
        let prevPage = 1
        if (this.state.currentPage > prevPage) {
            if (!this.state.search) {
                this.getBillsByPagination(this.state.currentPage - prevPage);
            } else {
                this.searchBillSchedule(this.state.currentPage - prevPage);
            }
        }
    };
    //Search Box Method
    searchBox = (e) => {
        this.setState({
            //assigning value to event target
            [e.target.name]: e.target.value,
        });
    };
    //Search Method Logic
    searchBillSchedule = (currentPage) => {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/bills/" + this.state.search + "?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    bills: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    };
    //Reset Search Box
    resetBill = (currentPage) => {
        this.setState({ "search": '' });
        this.getBillsByPagination(this.state.currentPage);
    };
    //Delete Book on the web page
    deleteBill = (bill_No) => {
        axios.delete("http://localhost:8080/api/v1/bills/" + bill_No).then(
            (response) => {
                alert("Record Deleted Successfully");
                this.setState({
                    bills: this.state.bills.filter(bill => bill.bill_No !== bill_No)
                });
            }, (error) => {
                alert("Operation Failed Here");
            }
        );
    };
    render() {
        const { bills, currentPage, totalPages, recordPerPage, search, patientName, results } = this.state;
        return (
            <div>
                <MenuBar/>
                <h1 className="text-center mt-5 menu-display">List of Bills</h1>
                <div className="container mt-2 menu-display-1">
                    <div style={{ float: 'center' }} align="center">
                    </div>
                    <input
                    type="text"
                    placeholder="Search for Patients using Name's..."
                    value={patientName}
                    onChange={this.handleInputChange}
                    />
                    <table className="table table-bordered border-info shadow">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Patient Name</th>
                                <th>Doctor Name</th>
                                <th>Amount</th>
                                <th>Insurance</th>
                                <th>Report Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bills.length === 0 ?
                                <tr align="center"><td colSpan="5">No Record Found</td></tr> :
                                (patientName==''?bills:results).map(
                                    (bills, index) => (
                                        <tr key={bills.bill_No}>
                                            <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td>
                                            <td>{bills.patientName}</td>
                                            <td>{bills.doctor_Name}</td>
                                            <td>{bills.amount}</td>
                                            <td>{bills.insurance}</td>
                                            <td>{bills.report_Status}</td>
                                            <td><button className="btn btn-outline-danger" onClick={() => { this.deleteBill(bills.bill_No) }}>Remove</button>
                                            <Link to={`/update-bills/${bills.bill_No}`}  className="btn btn-outline-dark">Edit</Link>
                                            </td>
                                        </tr>
                                    )
                                )
                            }
                        </tbody>
                    </table>
                    <table className="table">
                        <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
                            Page {currentPage} of {totalPages}
                        </div>
                        <div style={{ float: 'right' }}>
                            <div class="clearfix"></div>
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </table>
                </div>
                <Link to="/menubar_receptionist">
                <button className='login-btn'>Go Back</button>
                </Link>
            </div>
        )
    }
}
export default BillComponent