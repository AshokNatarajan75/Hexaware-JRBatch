import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Adder3 from './Adder3';
import MenuBar from '../Home/MenuBar';

function AddBill(){
    const navigate=useNavigate();
       //Step 1:
    const [bill, setBill] = useState({
        patientName: '',
        doctor_Name: '',
        amount: '',
        insurance: '',
        report_Status: ''
    });
    const [success,setSuccess] = useState('');
    //Step 3:
    const onInputChange = e => {
        setBill({ ...bill, [e.target.name]: e.target.value })
    }
    const { patientName, doctor_Name, amount, insurance, report_Status } = bill;
    const FormHandle = e => {
        e.preventDefault();
        addDataToServer(bill);
        setSuccess(true);
    }
    const handelClick=()=> {
        setBill({
            patientName: '',
            doctor_Name: '',
            amount: '',
            insurance: '',
            report_Status: '',
        });
    }
    const addDataToServer = (data) => {
        axios.post("http://localhost:8080/api/v1/bills", data).then(
            (response) => {
                console.log(response);
                alert("Bill Added Successfully");
            }, (error) => {
                console.log(error);
                alert("Operation failed");
            }
        );
    }
    return (
        <>
        {success ? (
        <section>
            <Adder3/>
        </section>
        ) :
        (<div>
            <MenuBar/>
            <div className="container menu-display-2">
                <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                    <div class="jumbotron">
                        <h1 class="display-4 text-center">Add Bill!</h1>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Patient Name</label>
                                    <input type="text" class="form-control" name="patientName"  placeholder="Enter Here" value={patientName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Doctor Name</label>
                                    <input type="text" class="form-control" name="doctor_Name"  placeholder="Enter Here" value={doctor_Name} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Amount</label>
                                    <input type="text" class="form-control" name="amount"  placeholder="Enter Here" value={amount} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Insurance</label>
                                    <input type="text" class="form-control" name="insurance"  placeholder="Enter Here" value={insurance} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Report Status</label>
                                    <input type="text" class="form-control" name="report_Status"  placeholder="Enter Here" value={report_Status} onChange={(e) => onInputChange(e)} required/>
                                </div>

                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Add Bill</button>
                                    <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Bill</button>
                                </div>
                            </form>
                            <br/>
                            <button className='login-btn' onClick={()=>navigate(-1)}>Go Back</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        )}
        </>
    )
    }


export default AddBill;