import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useParams, useNavigate } from "react-router-dom";
import MenuBar from '../Home/MenuBar';
function UpdateBill() {
    const { bill_No } = useParams(); // getting url id        
    const URL = `http://localhost:8080/api/v1/bill/bills/${bill_No}`;
    const navigate = useNavigate();

    useEffect(() => {
        getBillById();
    }, []);
    const [bill, setBill] = useState({
        patientName: '',
        doctor_Name: '',
        amount: '',
        insurance: '',
        report_Status: '',
    });
    const { patientName, doctor_Name, amount, insurance, report_Status } = bill;
    const onInputChange = e => {
        setBill({ ...bill, [e.target.name]: e.target.value })
    }
    const handelClick=()=> {
        setBill({
            patientName: '',
            doctor_Name: '',
            amount: '',
            insurance: '',
            report_Status: '',
        });
    }
    const FormHandle = e => {
        e.preventDefault();
        updateDataToServer(bill)
    }
    const updateDataToServer = (data) => {
        axios.put(URL, data).then(
            (response) => {
                alert("Bill Details Updated Successfully");
            }, (error) => {
                alert("Operation failed");
            }
        );
    };

    const getBillById = async e => {
        const billsInfo = await axios.get(URL);
        setBill(billsInfo.data);
    }

    return (
        <div>
            <MenuBar/>
            <div className="container menu-display-2">
                <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                    <div class="jumbotron">
                        <h1 class="display-4 text-center">Update Bill!</h1>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                            <div class="form-group">
                                    <label for="exampleInputEmail1">Patient Name</label>
                                    <input type="text" class="form-control" name="patientName"  placeholder="Enter Here" value={patientName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Doctor Name</label>
                                    <input type="text" class="form-control" name="doctor_Name"  placeholder="Enter Here" value={doctor_Name} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Amount</label>
                                    <input type="text" class="form-control" name="amount"  placeholder="Enter Here" value={amount} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Insurance</label>
                                    <input type="text" class="form-control" name="insurance"  placeholder="Enter Here" value={insurance} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Report Status</label>
                                    <input type="text" class="form-control" name="report_Status"  placeholder="Enter Here" value={report_Status} onChange={(e) => onInputChange(e)} required/>
                                </div>

                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Update Bill</button>
                                    <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Bill</button>
                                </div>
                            </form>
                            <br />
                            <button className='login-btn' onClick={() => navigate(-1)}>Go Back</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UpdateBill;