import {  useState } from "react";
import { Link,useNavigate } from 'react-router-dom';
import axios from "axios";
import DoctorScheduleComponent_Doctor from "../DoctorSchedule_Doctor/DoctorScheduleComponent_Doctor";
import MenuBar_Doctor from "./MenuBar_Doctor";
function Login_Doctor() {
   
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const navigate = useNavigate();
    async function login(event) {
        event.preventDefault();
        try {
          await axios.post("http://localhost:8080/api/v1/doctor/doctor_login", {
            email: email,
            password: password,
            }).then((res) => 
            {
              console.log(res.data);
             if (res.data.message == "Email not exits") 
             {
               alert("Email not exits");
             } 
             else if(res.data.message == "Login Success")
             { 
              navigate('/menubar_doctor');
             } 
              else 
             { 
                alert("Incorrect Email and Password not match");
             }
          }, fail => {
           console.error(fail); // Error!
  });
        }
 
         catch (err) {
          alert(err);
        }
      
      }
    return (
       <div>
            <div class="auth-form-container">
                <h2>Login</h2>
            <form className="login-form" onSubmit={login} >
            <label htmlFor="email">Email</label>
            <input 
            type="email" 
            id="email" 
            placeholder="Enter Email"
            value={email}
            onChange={(event) => {
              setEmail(event.target.value);
            }}
            required/>
            <label htmlFor="password">Password</label>
            <input 
            type="password"  
            id="password" 
            placeholder="Enter Password"
            value={password}
            onChange={(event) => {
              setPassword(event.target.value);
            }}
            required/>
            <button className="login-btn" type="submit" >Login</button>
            {/* {name && <DoctorScheduleComponent_Doctor name={name}/>} */}

            </form>
            {/* <Link to='/register_doctor'>
            <button className="link-btn">New User? Create Account</button>
            </Link> */}
            <Link to='/login_page'>
            <button className="login-btn">Go Back</button>
            </Link>
            </div>
            
     </div>
    );
  }
  
  export default Login_Doctor;