import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import  './style.css'
class MenuBar_Doctor extends Component {
    render() {

        return (
            <div>
                <nav class="navbar navbar-expand-lg navbar-dark bg-bg">
  <div class="container-fluid">
    <Link class="navbar-brand font-ch" href="#" to="/menubar_doctor">Home</Link>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">       
      <li class="nav-item">
          <Link class="nav-link active" aria-current="page" href="#" to="/display_doctor_doctor">Add Appointment</Link>
        </li>
      <li class="nav-item">
          <Link class="nav-link active" aria-current="page" href="#" to="/doctorschedule_component_doctor">List Appointment</Link>
        </li>        
        <li class="nav-item">
          <Link class="nav-link active" aria-current="page" href="#" to="/logout">LogOut</Link>
        </li>
      </ul>    
    </div>
  </div>
</nav>
<img src={require('./img4.jpg')}height={542} width={1232} ></img>

            </div>
        )
    }
}
export default MenuBar_Doctor