import React from 'react';
import { Link } from 'react-router-dom'
import './style.css';

class Home extends React.Component{
    render(){
        return(
            <div className='img1'>
                    <div className='home'>
                        <h1>Hinata Health Care</h1>
                        <h2>GooD AcE CarE</h2>
                        <h5>Health is Wealth</h5>
                        <div>
                        <p className='p'>Welcome to our Home Page<br/>
                        To proceed any further we request you<br/>
                        to login first
                        </p>
                        <h6 className='h6'>To Live Healthy<br/>
                                    Eat Healthy
                        </h6>
      <Link to='/login_page'>
      <button className='login_button_homepage'>Login</button>
      </Link>
      <br/><br/>
        <Link to='/about-us'>
        <button className='button-color-aboutus'>About Us</button>
        </Link>
        <Link to='/contact'>
        <button className='button-color-contact'>Contact</button>
        </Link>
                </div>
                </div>
            </div>
        )
    }
}

export default Home;
