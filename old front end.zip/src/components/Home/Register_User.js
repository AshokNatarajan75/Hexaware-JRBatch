import {  useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import { googleLogout, useGoogleLogin } from '@react-oauth/google';
import validator from "validator";

function Register_User() {
  
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [errors, setErrors] = useState([]);

    const navigate = useNavigate();
    const [ user, setUser ] = useState([]);
    const [ profile, setProfile ] = useState([]);
    const logingoogle = useGoogleLogin({
      onSuccess: (codeResponse) => setUser(codeResponse),
      onError: (error) => console.log('Login Failed:', error)
    });
    const logOut = () => {
    googleLogout();
    setProfile(null);
    };
    useEffect(
      () => {
          if (user) {
              axios
                  .get(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`, {
                      headers: {
                          Authorization: `Bearer ${user.access_token}`,
                          Accept: 'application/json'
                      }
                  })
                  .then((res) => {
                      setProfile(res.data);
                  })
                  .catch((err) => console.log(err));
          }
      },
      [ user ]
    );
    async function save(event) {
      if(password===''){
        alert("Password is not Strong")
      }
      else {
        event.preventDefault();
        try {
          await axios.post("http://localhost:8080/api/v1/user/save", {
          username: username || profile.name,
          email: email || profile.email,
          password: password || profile.name,
          });
          alert("User Registation Successfully");
          navigate('/login_user');
        } catch (err) {
          alert(err);
        }
      }
    }
      const validate = (value) => {
        if(validator.isStrongPassword(value, {
          minLength: 8, minLowercase: 1, minNumbers: 1,
          minSymbols: 1, minUppercase: 1
        })){
        setErrors('Is Strong Password')
        setPassword(value)
        }
      else {
        setErrors('Is not a strong Password')
      }
    }
  
    return (
        <div>
        <div className="auth-form-container">
            <h1>Register User</h1>
        <form className="register-form">
          <label>User name</label>
          <input 
          type="text" 
          id="username" 
          placeholder="Enter Name"
          value={username || profile.name}
          onChange={(event) => {
            setUsername(event.target.value);
          }}
          required/>
          <label>Email</label>
          <input 
          type="email"  
          id="email" 
          placeholder="Enter Email"
          value={email || profile.email}
          onChange={(event) => {
            setEmail(event.target.value);
          }}
          required/>
          <label>Password</label>
            <input 
            type="password"  
            id="password" 
            placeholder="Enter password"
            value={password || profile.name}
            onChange={(e) => validate(e.target.value)}
            required/>
                            {errors === '' ? null :
                    <span style={{
                        fontWeight: 'bold',
                        color: 'red',
                    }}>{errors}</span>}
          <button type="submit" class="login-btn" onClick={save} >Sign Up</button>
          </form>
        <button onClick={() => logingoogle()}>Sign in with Google 🚀 </button>
        <Link to='/login_user'>
            <button className="link-btn">Already have an account.<br/> Login</button>
        </Link>
        <Link to='/login_user'>
            <button className="login-btn">Go Back</button>
        </Link>
    </div>

    </div>
    );
  }
  
  export default Register_User;