import {  useState, useEffect } from "react";
import { Link,useNavigate } from 'react-router-dom';
import axios from "axios";
import { googleLogout, useGoogleLogin } from '@react-oauth/google';

function Login_User() {
   
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();
    const [ user, setUser ] = useState([]);
    const [ profile, setProfile ] = useState([]);
    const logingoogle = useGoogleLogin({
      onSuccess: (codeResponse) => setUser(codeResponse),
      onError: (error) => console.log('Login Failed:', error)
    });
    const logOut = () => {
    googleLogout();
    setProfile(null);
    };
    async function login(event) {
        event.preventDefault();
        try {
          await axios.post("http://localhost:8080/api/v1/user/user_login", {
            email: email || profile.email,
            password: password || profile.name,
            }).then((res) => 
            {
             console.log(res.data);
             
             if (res.data.message == "Email not exits") 
             {
               alert("Email not exits");
             } 
             else if(res.data.message == "Login Success")
             { 
                
                navigate('/menubar_user');
             } 
              else 
             { 
                alert("Incorrect Email and Password not match");
             }
          }, fail => {
           console.error(fail); // Error!
  });
        }
 
         catch (err) {
          alert(err);
        }
      
      }
      useEffect(
        () => {
            if (user) {
                axios
                    .get(`https://www.googleapis.com/oauth2/v1/userinfo?access_token=${user.access_token}`, {
                        headers: {
                            Authorization: `Bearer ${user.access_token}`,
                            Accept: 'application/json'
                        }
                    })
                    .then((res) => {
                        setProfile(res.data);
                    })
                    .catch((err) => console.log(err));
            }
        },
        [ user ]
    );
    return (
       <div>
            <div class="auth-form-container">
                <h2>Login</h2>
            <form className="login-form" onSubmit={login} >
            <label htmlFor="email">Email</label>
            <input 
            type="email" 
            id="email" 
            placeholder="Enter Email"
            value={email || profile.email}
            onChange={(event) => {
              setEmail(event.target.value);
            }}
            required/>
            <label htmlFor="password">Password</label>
            <input 
            type="password"  
            id="password" 
            placeholder="Enter Password"
            value={password || profile.name}
            onChange={(event) => {
              setPassword(event.target.value);
            }}
            required/>
            <button className="login-btn" type="submit" >Login</button>
            </form>
            <button onClick={() => logingoogle()}>Login in with Google 🚀 </button>
            <Link to='/register_user'>
            <button className="link-btn">New User? Create Account</button>
            </Link>
            <Link to='/login_page'>
            <button className="login-btn">Go Back</button>
            </Link>
            </div>
     </div>
    );
  }
  
  export default Login_User;