import React from 'react'
import { Link } from 'react-router-dom'
import Display_Doctor from '../DoctorSchedule/Display_Doctor'

const Contact = () => {
  return (
    <div>
      Welcome to Contact
      <br/><br/>
      <Display_Doctor/>
       <Link to='/'>
            <button className="login-btn">Go Back</button>
        </Link>
    </div>
  )
}

export default Contact
