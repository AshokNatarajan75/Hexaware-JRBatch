import React from "react";
import { Link } from 'react-router-dom'

class Login_Page extends React.Component{
    render(){
        return(
            <div>
            <div className="img_bg_loginpage"></div>
                <Link to='/login_receptionist'>
                <button className='button-color-loginpage-1'>Login as a Receptionist</button>
                </Link>
                <br/><br/>
                <Link to='/login_admin'>
                <button className='button-color-loginpage-2'>Login as a Admin</button>
                </Link>
                <br/><br/>
                <Link to='/login_doctor'>
                <button className='button-color-loginpage-3'>Login as a Doctor</button>
                </Link>
                <br/><br/>
                <Link to='/login_user'>
                <button className='button-color-loginpage-4'>Login as a User</button>
                </Link>
                <br/><br/>
                <Link to='/'>
                <button className='button-color-loginpage-5'>Go Back</button>
                </Link>
            </div>
        )
    }
}

export default Login_Page;