import axios from 'axios';
import React from 'react'
import { Link } from 'react-router-dom';
import MenuBar_Doctor from '../Home/MenuBar_Doctor';
class DoctorScheduleComponent_Doctor extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            doctorschedules: [],
            currentPage: 1,
            recordPerPage: 7,
            search: '',
            patientName: '',
            results: [],
            doctorName: '',
        }
    }
    componentDidMount() {
        this.getDoctorSchedulesByPagination(this.state.currentPage);
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.state.patientName !== prevState.patientName) {
            if (this.state.patientName) {
                axios.get(`http://localhost:8080/api/v1/search_doctorschedule_patientName?patientName=${this.state.patientName}`)
                    .then(response => {
                        console.log(response.data); 
                        this.setState({ results: response.data });})
                    .catch(error => console.error(error));
            } else {
                this.setState({ results: [] });
            }
        }
    }

    handleInputChange = e => {
        this.setState({ patientName: e.target.value });
    };

    componentDidUpdate(prevProps, prevState) {
        if (this.state.doctorName !== prevState.doctorName) {
            if (this.state.doctorName) {
                axios.get(`http://localhost:8080/api/v1/search_doctorschedule_doctorName?doctorName=${this.state.doctorName}`)
                    .then(response => {
                        console.log(response.data); 
                        this.setState({ results: response.data });})
                    .catch(error => console.error(error));
            } else {
                this.setState({ results: [] });
            }
        }
    }

    handleInputChange1 = e => {
        this.setState({ doctorName: e.target.value });
    };

    getDoctorSchedulesByPagination(currentPage) {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/doctorSchedules?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    doctorschedules: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    }
    //Writing All the pagination functions
    //Show Next page
    showNextPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getDoctorSchedulesByPagination(this.state.currentPage + 1);
            } else {
                this.searchDoctorSchedule(this.state.currentPage + 1)
            }
        }
    };
    //Show Last Page
    showLastPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getDoctorSchedulesByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
            else {
                this.searchDoctorSchedule(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
        }
    };
    //Show First page
    showFirstPage = () => {
        let firstPage = 1;
        if (this.state.currentPage > firstPage) {
            if (!this.state.search) {
                this.getDoctorSchedulesByPagination(firstPage);
            } else {
                this.searchDoctorSchedule(firstPage)
            }
        }
    };
    //Show previous page
    showPrevPage = () => {
        let prevPage = 1
        if (this.state.currentPage > prevPage) {
            if (!this.state.search) {
                this.getDoctorSchedulesByPagination(this.state.currentPage - prevPage);
            } else {
                this.searchDoctorSchedule(this.state.currentPage - prevPage);
            }
        }
    };
    //Search Box Method
    searchBox = (e) => {
        this.setState({
            //assigning value to event target
            [e.target.name]: e.target.value,
        });
    };
    //Search Method Logic
    searchDoctorSchedule = (currentPage) => {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/doctorSchedules/" + this.state.search + "?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    doctorschedules: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    };
    //Reset Search Box
    resetPatient = (currentPage) => {
        this.setState({ "search": '' });
        this.getDoctorSchedulesByPagination(this.state.currentPage);
    };
    //Delete Book on the web page
    deleteDoctorSchedule = (appointment_No) => {
        axios.delete("http://localhost:8080/api/v1/doctorSchedules/" + appointment_No).then(
            (response) => {
                alert("Record Deleted Successfully");
                this.setState({
                    doctorschedules: this.state.doctorschedules.filter(doctorschedule => doctorschedule.appointment_No !== appointment_No)
                });
            }, (error) => {
                alert("Operation Failed Here");
            }
        );
    };
    render() {
        const { doctorschedules, currentPage, totalPages, recordPerPage, search, patientName, results, doctorName } = this.state;
        return (
            <div>
                <MenuBar_Doctor/>
                <h1 className="text-center mt-5 menu-display">List of Appointments</h1>
                <div className="container mt-2 menu-display-1">
                    <div style={{ float: 'center' }} align="center">
                    </div>
                    {/* <input
                    type="text"
                    placeholder="Search for Patients using Name's..."
                    value={patientName}
                    onChange={this.handleInputChange}
                    /> */}
                    <input
                    type="text"
                    placeholder="Search for Doctor using Name's..."
                    value={doctorName}
                    onChange={this.handleInputChange1}
                    />                    
                    <table className="table table-bordered border-info shadow">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Patient Name</th>
                                <th>Doctor Name</th>
                                <th>Timing</th>
                                <th>Issue</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {doctorschedules.length === 0 ?
                                <tr align="center"><td colSpan="5">No Record Found</td></tr> :
                                (doctorName ==''?doctorschedules:results).map(
                                    (doctorschedules, index) => (
                                        <tr key={doctorschedules.appointment_No}>
                                            <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td>
                                            <td>{doctorschedules.patientName}</td>
                                            <td>{doctorschedules.doctorName}</td>
                                            <td>{doctorschedules.timing}</td>
                                            <td>{doctorschedules.issue}</td>
                                            <td>{doctorschedules.status}</td>
                                            <td><button className="btn btn-outline-danger" onClick={() => { this.deleteDoctorSchedule(doctorschedules.appointment_No) }}>Remove</button>
                                            <Link to={`/update-doctorschedules-doctor/${doctorschedules.appointment_No}`}  className="btn btn-outline-dark">Edit</Link>
                                            </td>
                                        </tr>
                                    )
                                )
                            }
                        </tbody>
                    </table>
                    <table className="table">
                        <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
                            Page {currentPage} of {totalPages}
                        </div>
                        <div style={{ float: 'right' }}>
                            <div class="clearfix"></div>
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </table>
                <Link to="/menubar_doctor">
                <button className='login-btn'>Go Back</button>
                </Link>
                </div>
            </div>
        )
    }
}
export default DoctorScheduleComponent_Doctor