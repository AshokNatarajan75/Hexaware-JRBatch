import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useParams, useNavigate } from "react-router-dom";
import MenuBar_Doctor from '../Home/MenuBar_Doctor';

function UpdateDoctorSchedule_Doctor() {
    const { appointment_No } = useParams(); // getting url id        
    const URL = `http://localhost:8080/api/v1/doctorSchedule/doctorSchedules/${appointment_No}`;
    const navigate = useNavigate();

    useEffect(() => {
        getDoctorScheduleById();
    }, []);
    const [doctorschedule, setDoctorschedule] = useState({
        patientName: '',
        doctorName: '',
        timing: '',
        issue: '',
        status: '',
    });
    const handelClick = () => {
        setDoctorschedule({
            patientName: '',
            doctorName: '',
            timing: '',
            issue: '',
            status: '',
        });
    }
    const { patientName, doctorName, timing, issue, status } = doctorschedule;
    const onInputChange = e => {
        setDoctorschedule({ ...doctorschedule, [e.target.name]: e.target.value })
    }

    const FormHandle = e => {
        e.preventDefault();
        updateDataToServer(doctorschedule)
    }
    const updateDataToServer = (data) => {
        axios.put(URL, data).then(
            (response) => {
                alert("Schedule Details Updated Successfully");
            }, (error) => {
                alert("Operation failed");
            }
        );
    };

    const getDoctorScheduleById = async e => {
        const doctorschedulesInfo = await axios.get(URL);
        setDoctorschedule(doctorschedulesInfo.data);
    }

    return (
        <div>
            <MenuBar_Doctor/>
            <div className="container menu-display-2">
                <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                    <div class="jumbotron">
                        <h1 class="display-4 text-center">Update Schedule!</h1>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Patient Name</label>
                                    <input type="text" class="form-control" name="patientName" placeholder="Enter Here" value={patientName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Doctor Name</label>
                                    <input type="text" class="form-control" name="doctorName" placeholder="Enter Here" value={doctorName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Timing</label>
                                    <input type="text" class="form-control" name="timing" placeholder="Enter Here" value={timing} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Issue</label>
                                    <input type="text" class="form-control" name="issue" placeholder="Enter Here" value={issue} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Status</label>
                                    <input type="text" class="form-control" name="status" placeholder="Enter Here" value={status} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-success my-2 text-center mr-2">Update Schedule</button>
                                    <button type="reset" onClick={() => handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Schedule</button>
                                </div>
                            </form>
                            <br />
                            <button className='login-btn' onClick={() => navigate(-1)}>Go Back</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UpdateDoctorSchedule_Doctor;