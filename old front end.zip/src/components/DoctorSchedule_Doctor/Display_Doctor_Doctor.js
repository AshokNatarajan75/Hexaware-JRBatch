import React from 'react'
import { Link } from 'react-router-dom'
import MenuBar_Doctor from '../Home/MenuBar_Doctor'

const Display_Doctor_Doctor = () => {
  return (
    <div>
        <MenuBar_Doctor/>
    <br></br>
    <div class="container mt-5 mb-5 menu-display">
    <div class="d-flex justify-content-between mb-3">
       <h4><span>Doctors</span></h4>
    </div>
    <div class="row g-2">
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/LohyFIN.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Ram</h5>
                <small>Skin</small>
                <div class="ratings mt-2">
                    {/* <i class="fa fa-star">***</i> */}
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/o5uMfKo.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Aravind</h5>
                <small>Kidney</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/tmdHXOY.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Mohit Agarwal</h5>
                <small>Neurologist</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/C4egmYM.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Kishan Bankai</h5>
                <small>Dentist</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/0LKZQYM.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Chidori Chinna</h5>
                <small>Dermatologist</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/ZSkeqnd.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Lisa Leens</h5>
                <small>Psychiatrist</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/MZm1LNz.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Gol D Roger</h5>
                <small>Surgeon</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/HFpxxJz.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Bock</h5>
                <small>Primary Care</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card p-2 py-3 text-center">
                {/* <div class="img mb-2">
                    <img src="https://i.imgur.com/HFpxxJz.jpg" width="70" class="rounded-circle"></img>
                </div> */}
                <h5 class="mb-0">Ankit</h5>
                <small>Primary Care</small>
                <div class="ratings mt-2">
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                </div>
                <div class="mt-4 apointment">
                    <button class="btn btn-success text-uppercase"><Link class="nav-link active" aria-current="page" href="#" to="/adddoctorschedule_doctor">Book Appointment</Link></button>
                </div>
            </div>
        </div>
    </div>
   </div>
       <Link to='/menubar_doctor'>
            <button className="login-btn">Go Back</button>
        </Link>
    </div>
  )
}

export default Display_Doctor_Doctor