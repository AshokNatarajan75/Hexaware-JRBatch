import React from 'react';

function Email_Doctor(props) {
  const { name, date, time, link } = props;

  const subject = `Confirmation: User Added ${name}`;
  const body = `Dear User,\n\nThank you for registering for our portal on ${date} at ${time}.\n\nBest regards,\nMeeting Organizer`;

  const handleClick = () => {
    const mailtoLink = `mailto:${props.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
  }

  return (
    <div>
      <h2>Patient Adding Confirmation</h2>
      <p>Dear Users!,</p>
      <p>Thank you for registering for our portal on {date} at {time}. </p>
      <button onClick={handleClick}>Send Confirmation Email</button>
    </div>
  );
}

export default Email_Doctor;