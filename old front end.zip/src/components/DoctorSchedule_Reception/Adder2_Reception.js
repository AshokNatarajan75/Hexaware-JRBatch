import React from 'react'
import { Link } from 'react-router-dom'

const Adder2_Reception = () => {
  return (
    <div>
      <h1>Added Successfully</h1>
      <Link to="/doctorschedule_component_Reception">
        <button className='login-btn'>Show List</button>
      </Link>
      <br/><br/>
      <Link to="/menubar_receptionist">
        <button className='login-btn'>Back to Home</button>
      </Link>
    </div>
  )
}

export default Adder2_Reception
