import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Adder2_Reception from './Adder2_Reception';
import MenuBar from '../Home/MenuBar';

function AddDoctorSchedule_Reception(){
    const navigate=useNavigate();
       //Step 1:
    const [doctorschedule, setDoctorschedule] = useState({
        patientName: '',
        doctorName: '',
        timing: '',
        issue:'',
        status: '',
    });
    const handelClick=()=> {
        setDoctorschedule({
            patientName: '',
            doctorName: '',
            timing: '',
            issue:'',
            status: '', 
        });
    }
    const [success,setSuccess] = useState('');
    //Step 3:
    const onInputChange = e => {
        setDoctorschedule({ ...doctorschedule, [e.target.name]: e.target.value })
    }
    const { patientName, doctorName, timing, issue, status } = doctorschedule;
    const FormHandle = e => {
        e.preventDefault();
        addDataToServer(doctorschedule);
        setSuccess(true);
    }
    const addDataToServer = (data) => {
        axios.post("http://localhost:8080/api/v1/doctorSchedules", data).then(
            (response) => {
                console.log(response);
                alert("Appointment Added Successfully");
            }, (error) => {
                console.log(error);
                alert("Operation failed");
            }
        );
    }
    return (
        <>
        {success ? (
        <section>
            <Adder2_Reception/>
        </section>
        ) :
        (<div>
            <MenuBar/>
            <div className="container menu-display-2">
                <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                    <div class="jumbotron">
                        <h1 class="display-4 text-center">Add Appointment!</h1>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Patient Name</label>
                                    <input type="text" class="form-control" name="patientName"  placeholder="Enter Here" value={patientName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Doctor Name</label>
                                    <input type="text" class="form-control" name="doctorName"  placeholder="Enter Here" value={doctorName} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Timing</label>
                                    <input type="text" class="form-control" name="timing"  placeholder="Enter Here" value={timing} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Issue</label>
                                    <input type="text" class="form-control" name="issue"  placeholder="Enter Here" value={issue} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Status</label>
                                    <input type="text" class="form-control" name="status"  placeholder="Enter Here" value={status} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Add Appointment</button>
                                    <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Appointment</button>
                                </div>
                            </form>
                            <br/>
                            <button className='login-btn' onClick={()=>navigate(-1)}>Go Back</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        )}
        </>
    )
    }


export default AddDoctorSchedule_Reception;