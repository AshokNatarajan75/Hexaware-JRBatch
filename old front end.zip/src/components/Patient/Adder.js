import React from 'react'
import { Link } from 'react-router-dom'

const Adder = () => {
  return (
    <div>
      <h1>Added Successfully</h1>
      <Link to="/patient_Component">
        <button className='login-btn'>Show List</button>
      </Link>
      <br/><br/>
      <Link to="/menubar_receptionist">
        <button className='login-btn'>Back to Home</button>
      </Link>
    </div>
  )
}

export default Adder
