import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Adder from './Adder';
import MenuBar from '../Home/MenuBar';
//import Email from '../DoctorSchedule/Email';

function AddPatientsComponent(){
    const navigate=useNavigate();
       //Step 1:
    const [patient, setPatient] = useState({
        patientName: '',
        gender: '',
        age: '',
        bloodGroup:'',
        phoneNumber: '',
        issue: '',
        status: ''
    });
    const handelClick=()=> {
        setPatient({
            patientName: '',
            gender: '',
            age: '',
            bloodGroup:'',
            phoneNumber: '',
            issue: '',
            status: ''  
        });
    }
    const [success,setSuccess] = useState('');
    //Step 3:
    const onInputChange = e => {
        setPatient({ ...patient, [e.target.name]: e.target.value })
    }
    const { patientName, gender, age, bloodGroup, phoneNumber, issue, status } = patient;
    const FormHandle = e => {
        e.preventDefault();
        addDataToServer(patient);
        setSuccess(true);
    }
    const addDataToServer = (data) => {
        axios.post("http://localhost:8080/api/v1/patients", data).then(
            (response) => {
                console.log(response);
                alert("Patient Added Successfully");
            }, (error) => {
                console.log(error);
                alert("Operation failed");
            }
        );
    }
    return (
        <>
        {success ? (
        <section>
            <Adder/>
           {/*} <Email/>*/}
        </section>
        ) :
        (<div>
            <MenuBar/>
            <div className="container menu-display-2">
                <div className="shadow p-5 bg-light">
               {/*</div> <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">   */}
                    <div class="jumbotron">
                        <h2 class="display-4 text-center">Add Patient!</h2>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Patient Name</label>
                                    <input type="text" class="form-control" name="patientName"  placeholder="Enter Here" value={patientName} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Gender</label>
                                    <input type="text" class="form-control" name="gender"  placeholder="Enter Here" value={gender} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Age</label>
                                    <input type="text" class="form-control" name="age"  placeholder="Enter Here" value={age} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Blood Group</label>
                                    <input type="text" class="form-control" name="bloodGroup"  placeholder="Enter Here" value={bloodGroup} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Phone Number</label>
                                    <input type="text" class="form-control" name="phoneNumber"  placeholder="Enter Here" value={phoneNumber} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Issue</label>
                                    <input type="text" class="form-control" name="issue"  placeholder="Enter Here" value={issue} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Status</label>
                                    <input type="text" class="form-control" name="status"  placeholder="Enter Here" value={status} onChange={(e) => onInputChange(e)} />
                                </div>
                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Add Patient</button>
                                    <br/>
                                    <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Patient</button>
                                </div>
                                <br/>
                            <button className='login-btn' onClick={()=>navigate(-1)}>Go Back</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        )}
        </>
    )
    }


export default AddPatientsComponent;