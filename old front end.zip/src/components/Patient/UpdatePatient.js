import React,{useState,useEffect} from 'react'
import axios from 'axios';
import {useParams,useNavigate} from "react-router-dom";
import MenuBar from '../Home/MenuBar';
function UpdatePatient() {
    const {patient_id} = useParams(); // getting url id        
    const URL = `http://localhost:8080/api/v1/patient/patients/${patient_id}`;
    const navigate=useNavigate();

    useEffect(()=>{
        getPatientById();
    },[]);
    const [patient, setPatient] = useState({
        patientName: '',
        gender: '',
        age: '',
        bloodGroup:'',
        phoneNumber: '',
        issue: '',
        status: ''  
    });
    const handelClick=()=> {
        setPatient({
            patientName: '',
            gender: '',
            age: '',
            bloodGroup:'',
            phoneNumber: '',
            issue: '',
            status: ''  
        });
    }
    const { patientName , gender , age, bloodGroup, phoneNumber, issue, status} = patient;
    const onInputChange = e =>{
        setPatient({...patient,[e.target.name]:e.target.value})
    }
    
    const FormHandle = e =>{
        e.preventDefault();
        updateDataToServer(patient)      
    }
    const updateDataToServer=(data) =>{
        axios.put(URL,data).then(
           (response)=>{
                   alert("Patinet Details Updated Successfully");
            },(error)=>{
                    alert("Operation failed");
            }
        );
    };
    
    const getPatientById= async e =>{
        const patientsInfo = await axios.get(URL);
        setPatient(patientsInfo.data);       
    }
   
    return (
        <div>
            <MenuBar/>
            <div className="container menu-display-2">
            <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                <div class="jumbotron">
                    <h1 class="display-4 text-center">Update Patient!</h1>
                    <div>
                    <form onSubmit={e => FormHandle(e)}>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Patient Name</label>
                            <input type="text" class="form-control" name="patientName"   placeholder="Enter Here" value={patientName} onChange={(e) =>onInputChange(e)} />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Gender</label>
                            <input type="text" class="form-control" name="gender"   placeholder="Enter Here" value={gender} onChange={(e) =>onInputChange(e)} />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Age</label>
                            <input type="text" class="form-control" name="age"  placeholder="Enter Here" value={age} onChange={(e) =>onInputChange(e)}  />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Blood Group</label>
                            <input type="text" class="form-control" name="bloodGroup"  placeholder="Enter Here" value={bloodGroup} onChange={(e) =>onInputChange(e)}  />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Phone Number</label>
                            <input type="text" class="form-control" name="phoneNumber"  placeholder="Enter Here" value={phoneNumber} onChange={(e) =>onInputChange(e)}  />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Issue</label>
                            <input type="text" class="form-control" name="issue"  placeholder="Enter Here" value={issue} onChange={(e) =>onInputChange(e)}  />
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Status</label>
                            <input type="text" class="form-control" name="status"  placeholder="Enter Here" value={status} onChange={(e) =>onInputChange(e)}  />
                        </div>
                        <div className="container text-center">
                        <button type="submit" class="btn btn-outline-success my-2 text-center mr-2">Update Patient</button>
                        <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Patient</button>
                        </div>
                    </form>
                    <br/>
                    <button className='login-btn' onClick={()=>navigate(-1)}>Go Back</button>
                </div>
            </div>
            </div>
        </div>
        </div>
    )
}

export default UpdatePatient;