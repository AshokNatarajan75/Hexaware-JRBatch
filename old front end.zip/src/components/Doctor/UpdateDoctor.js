import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { useParams, useNavigate } from "react-router-dom";
import MenuBar_Admin from '../Home/MenuBar_Admin';
function UpdateDoctor() {
    const { doctor_id } = useParams(); // getting url id        
    const URL = `http://localhost:8080/api/v1/doctor/doctor/doctors/${doctor_id}`;
    const navigate = useNavigate();

    useEffect(() => {
        getDoctorById();
    }, []);
    const [doctor, setDoctor] = useState({
        name: '',
        age: '',
        gender: '',
        specialization: '',
        experience: '',
        language: '',
        mobile_No: '',
        email: '',
        schedule: ''
    });
    const { name, age, gender, specialization, experience, language, mobile_No, email, schedule } = doctor;
    const onInputChange = e => {
        setDoctor({ ...doctor, [e.target.name]: e.target.value })
    }
    const handelClick=()=> {
        setDoctor({
            name: '',
            age: '',
            gender: '',
            specialization: '',
            experience: '',
            language: '',
            mobile_No: '',
            email: '',
            schedule: ''
        });
    }
    const FormHandle = e => {
        e.preventDefault();
        updateDataToServer(doctor)
    }
    const updateDataToServer = (data) => {
        axios.put(URL, data).then(
            (response) => {
                alert("Doctor Details Updated Successfully");
            }, (error) => {
                alert("Operation failed");
            }
        );
    };

    const getDoctorById = async e => {
        const doctorsInfo = await axios.get(URL);
        setDoctor(doctorsInfo.data);
    }

    return (
        <div>
            <MenuBar_Admin/>
            <div className="container menu-display-2">
                <div className="w-75 mx-auto shadow p-5 mt-2 bg-light">
                    <div class="jumbotron">
                        <h1 class="display-4 text-center">Update Doctor!</h1>
                        <div>
                            <form onSubmit={e => FormHandle(e)}>
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Doctor Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Enter Here" value={name} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Age</label>
                                    <input type="text" class="form-control" name="age" placeholder="Enter Here" value={age} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Gender</label>
                                    <input type="text" class="form-control" name="gender" placeholder="Enter Here" value={gender} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Specialization</label>
                                    <input type="text" class="form-control" name="specialization" placeholder="Enter Here" value={specialization} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Experience</label>
                                    <input type="text" class="form-control" name="experience" placeholder="Enter Here" value={experience} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Language</label>
                                    <input type="text" class="form-control" name="language" placeholder="Enter Here" value={language} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Mobile_No</label>
                                    <input type="text" class="form-control" name="mobile_No" placeholder="Enter Here" value={mobile_No} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Email_ID</label>
                                    <input type="text" class="form-control" name="email" placeholder="Enter Here" value={email} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputPassword1">Schedule</label>
                                    <input type="text" class="form-control" name="schedule" placeholder="Enter Here" value={schedule} onChange={(e) => onInputChange(e)} required/>
                                </div>
                                <div className="container text-center">
                                    <button type="submit" class="btn btn-outline-secondary my-2 text-center mr-2">Update Doctor</button>
                                    <button type="reset" onClick={()=>handelClick()} class="btn btn-outline-primary text-center mr-2">Clear Doctor</button>
                                </div>
                            </form>
                            <br />
                            <button className='login-btn' onClick={() => navigate(-1)}>Go Back</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default UpdateDoctor;