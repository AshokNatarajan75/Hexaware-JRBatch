import axios from 'axios';
import React from 'react'
import { Button, Row } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import MenuBar_Admin from '../Home/MenuBar_Admin';
class DoctorComponent extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            doctors: [],
            currentPage: 1,
            recordPerPage: 7,
            search: '',
            name: '',
            results: [],
        }
    }
    componentDidMount() {
        this.getDoctorsByPagination(this.state.currentPage);
    }
    componentDidUpdate(prevProps, prevState) {
        if (this.state.name !== prevState.name) {
            if (this.state.name) {
                axios.get(`http://localhost:8080/api/v1/doctor/search_doctor?name=${this.state.name}`)
                    .then(response => {
                        console.log(response.data); 
                        this.setState({ results: response.data });})
                    .catch(error => console.error(error));
            } else {
                this.setState({ results: [] });
            }
        }
    }

    handleInputChange = e => {
        this.setState({ name: e.target.value });
    };

    getDoctorsByPagination(currentPage) {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/doctor/doctors?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    doctors: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    }
    //Writing All the pagination functions
    //Show Next page
    showNextPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getDoctorsByPagination(this.state.currentPage + 1);
            } else {
                this.searchDoctor(this.state.currentPage + 1)
            }
        }
    };
    //Show Last Page
    showLastPage = () => {
        if (this.state.currentPage < Math.ceil(this.state.totalElements / this.state.recordPerPage)) {
            if (!this.state.search) {
                this.getDoctorsByPagination(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
            else {
                this.searchDoctor(Math.ceil(this.state.totalElements / this.state.recordPerPage));
            }
        }
    };
    //Show First page
    showFirstPage = () => {
        let firstPage = 1;
        if (this.state.currentPage > firstPage) {
            if (!this.state.search) {
                this.getDoctorsByPagination(firstPage);
            } else {
                this.searchDoctor(firstPage)
            }
        }
    };
    //Show previous page
    showPrevPage = () => {
        let prevPage = 1
        if (this.state.currentPage > prevPage) {
            if (!this.state.search) {
                this.getDoctorsByPagination(this.state.currentPage - prevPage);
            } else {
                this.searchDoctor(this.state.currentPage - prevPage);
            }
        }
    };
    //Search Box Method
    searchBox = (e) => {
        this.setState({
            //assigning value to event target
            [e.target.name]: e.target.value,
        });
    };
    //Search Method Logic
    searchDoctor = (currentPage) => {
        currentPage = currentPage - 1;
        axios.get("http://localhost:8080/api/v1/doctor/doctors/" + this.state.search + "?page=" + currentPage + "&size=" + this.state.recordPerPage)
            .then(response => response.data).then((data) => {
                this.setState({
                    doctors: data.content,
                    totalPages: data.totalPages,
                    totalElements: data.totalElements,
                    currentPage: data.number + 1
                });
            });
    };
    //Reset Search Box
    resetDoctor = (currentPage) => {
        this.setState({ "search": '' });
        this.getDoctorsByPagination(this.state.currentPage);
    };
    //Delete Doctor on the web page
    deleteDoctor = (doctor_id) => {
        axios.delete("http://localhost:8080/api/v1/doctor/doctors/" + doctor_id).then(
            (response) => {
                alert("Record Deleted Successfully");
                this.setState({
                    doctors: this.state.doctors.filter(doctor => doctor.doctor_id !== doctor_id)
                });
            }, (error) => {
                alert("Operation Failed Here");
            }
        );
    };
    render() {
        const { doctors, currentPage, totalPages, recordPerPage, search, name, results } = this.state;
        return (
            <div>
                <MenuBar_Admin/>
                <h1 className="text-center mt-5 menu-display">List of Doctors</h1>
                <div className="container mt-2 menu-display-1">
                    <div style={{ float: 'center' }} align="center">
                    </div>
                    <input
                    type="text"
                    placeholder="Search for Patients using Name's..."
                    value={name}
                    onChange={this.handleInputChange}
                    />
                    <table className="table table-bordered border-info shadow">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Doctor Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Specialization</th>
                                <th>Experience</th>
                                <th>Language</th>
                                <th>Mobile_No</th>
                                <th>Email_ID</th>
                                <th>Schedule</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {doctors.length === 0 ?
                                <tr align="center"><td colSpan="5">No Record Found</td></tr> :
                                (name==''?doctors:results).map(
                                    (doctors, index) => (
                                        <tr key={doctors.doctor_id}>
                                            <td>{(recordPerPage * (currentPage - 1)) + index + 1}</td>
                                            <td>{doctors.name}</td>
                                            <td>{doctors.age}</td>
                                            <td>{doctors.gender}</td>
                                            <td>{doctors.specialization}</td>
                                            <td>{doctors.experience}</td>
                                            <td>{doctors.language}</td>
                                            <td>{doctors.mobile_No}</td>
                                            <td>{doctors.email}</td>
                                            <td>{doctors.schedule}</td>
                                            <td><button className="btn btn-outline-danger" onClick={() => { this.deleteDoctor(doctors.doctor_id) }}>Fire</button>
                                            <Link to={`/update-doctors/${doctors.doctor_id}`} className="btn btn-outline-dark">Edit</Link>
                                            </td>
                                        </tr>
                                    )
                                )
                            }
                        </tbody>
                    </table>
                    <table className="table">
                        <div style={{ float: 'left', fontFamily: 'monospace', color: '#0275d8' }}>
                            Page {currentPage} of {totalPages}
                        </div>
                        <div style={{ float: 'right' }}>
                            <div class="clearfix"></div>
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showPrevPage}>Previous</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === 1 ? true : false} onClick={this.showFirstPage}>First</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showNextPage}>Next</a></li>
                                    <li class="page-item"><a type="button" class="page-link" disabled={currentPage === totalPages ? true : false} onClick={this.showLastPage}>Last</a></li>
                                </ul>
                            </nav>
                        </div>
                    </table>
                </div>
                <Link to="/menubar_admin">
                <button className='login-btn'>Go Back</button>
                </Link>
            </div>
        )
    }
}
export default DoctorComponent