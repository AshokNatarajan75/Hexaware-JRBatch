import { BrowserRouter,Routes,Route } from "react-router-dom";
import Home from "./components/Home/Home";
import Register_Reseptionist from "./components/Register_Receptionist";
import Login_Receptionist from "./components/Login_Receptionist";
import Login_Page from "./components/Home/Login_Page";
import AboutUs from "./components/Home/AboutUs";
import Contact from "./components/Home/Contact";
import MenuBar from "./components/Home/MenuBar";
import Login_User from "./components/Home/Login_User";
import Register_User from "./components/Home/Register_User";
import AddPatientsComponent from "./components/Patient/AddPatientsComponent";
import PatientComponent from "./components/Patient/PatientComponent";
import UpdatePatient from "./components/Patient/UpdatePatient";
import AddBill from "./components/Bill/AddBill";
import BillComponent from "./components/Bill/BillComponent";
import UpdateBill from "./components/Bill/UpdateBill";
import LogOut from "./components/Home/LogOut";
import Login_Admin from "./components/Home/Login_Admin";
import Login_Doctor from "./components/Home/Login_Doctor";
import Register_Doctor from "./components/Home/Register_Doctor";
import DoctorComponent from "./components/Doctor/DoctorComponents";
import UpdateDoctor from "./components/Doctor/UpdateDoctor";
import MenuBar_Admin from "./components/Home/MenuBar_Admin";
import MenuBar_User from "./components/Home/MenuBar_User";
import AddDoctorSchedule from "./components/DoctorSchedule/AddDoctorSchedule";
import DoctorScheduleComponent from "./components/DoctorSchedule/DoctorScheduleComponent";
import UpdateDoctorSchedule from "./components/DoctorSchedule/UpdateDoctorSchedule";
import AddDoctorSchedule_Reception from "./components/DoctorSchedule_Reception/AddDoctorSchedule_Reception";
import DoctorScheduleComponent_Reception from "./components/DoctorSchedule_Reception/DoctorScheduleComponent_Reception";
import UpdateDoctorSchedule_Reception from "./components/DoctorSchedule_Reception/UpdateDoctorSchedule_Reception";
import MenuBar_Doctor from "./components/Home/MenuBar_Doctor";
import AddDoctorSchedule_Doctor from "./components/DoctorSchedule_Doctor/AddDoctorSchedule_Doctor";
import DoctorScheduleComponent_Doctor from "./components/DoctorSchedule_Doctor/DoctorScheduleComponent_Doctor";
import UpdateDoctorSchedule_Doctor from "./components/DoctorSchedule_Doctor/UpdateDoctorSchedule_Doctor";
import Display_Doctor from "./components/DoctorSchedule/Display_Doctor";
import Display_Doctor_Doctor from "./components/DoctorSchedule_Doctor/Display_Doctor_Doctor";
import Display_Doctor_Reception from "./components/DoctorSchedule_Reception/Display_Doctor_Reception";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
            <Routes>
              <Route path="/" element= { <Home/>} />
              <Route path="/register_receptionist" element= { <Register_Reseptionist/>} />
              <Route path="/login_receptionist" element= { <Login_Receptionist/>} />
              <Route path="/login_page" element={ <Login_Page/>} />
              <Route path="/about-us" element={ <AboutUs/>} />
              <Route path="/contact" element={ <Contact/>} />
              <Route path="/menubar_receptionist" element={ <MenuBar/>} />
              <Route path="/login_user" element={ <Login_User/>} />
              <Route path="/register_user" element={ <Register_User/>} />
              <Route path="/add_patient" element={ <AddPatientsComponent/>} />
              <Route path="/patient_component" element={ <PatientComponent/>} />
              <Route path="/update-patients/:patient_id" element={ <UpdatePatient/>} />
              <Route path="/add_bill" element={ <AddBill/>} />
              <Route path="/bill_component" element={ <BillComponent/>} />
              <Route path="/update-bills/:bill_No" element={ <UpdateBill/>} />
              <Route path="/logout" element={ <LogOut/>} />
              <Route path="/login_admin" element={ <Login_Admin/>} />
              <Route path="/login_doctor" element={ <Login_Doctor/>} />
              <Route path="/add_doctor" element={ <Register_Doctor/>} />
              <Route path="/doctor_component" element={ <DoctorComponent/>} />
              <Route path="/update-doctors/:doctor_id" element={ <UpdateDoctor/>} />
              <Route path="/menubar_admin" element={ <MenuBar_Admin/>} />
              <Route path="/menubar_user" element={ <MenuBar_User/>} />
              <Route path="/adddoctorschedule" element={ <AddDoctorSchedule/>} />
              <Route path="/doctorschedule_component" element={ <DoctorScheduleComponent/>} />
              <Route path="/update-doctorschedules/:appointment_No" element={ <UpdateDoctorSchedule/>} />              
              <Route path="/adddoctorschedule_reception" element={ <AddDoctorSchedule_Reception/>} />
              <Route path="/doctorschedule_component_reception" element={ <DoctorScheduleComponent_Reception/>} />
              <Route path="/update-doctorschedules-reception/:appointment_No" element={ <UpdateDoctorSchedule_Reception/>} />
              <Route path="/adddoctorschedule_doctor" element={ <AddDoctorSchedule_Doctor/>} />
              <Route path="/doctorschedule_component_doctor" element={ <DoctorScheduleComponent_Doctor/>} />
              <Route path="/update-doctorschedules-doctor/:appointment_No" element={ <UpdateDoctorSchedule_Doctor/>} />
              <Route path="/menubar_doctor" element={ <MenuBar_Doctor/>} />
              <Route path="/display_doctor" element={ <Display_Doctor/>} />
              <Route path="/display_doctor_doctor" element={ <Display_Doctor_Doctor/>} />
              <Route path="/display_doctor_reception" element={ <Display_Doctor_Reception/>} />
            </Routes>
        </BrowserRouter>
      
    </div>
  );
}
export default App;